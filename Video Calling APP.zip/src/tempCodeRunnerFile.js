
            name,
            ...preferences,