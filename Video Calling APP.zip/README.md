# Google-Meet-Clone

<p align="center"> 
  <h3 align="center">Google Meet Clone</h3>

  <p align="center">
    Google Meet Clone!
    <br />  
     A Video Conference App Similar to Google Meet
    <br />
  </p>
</p>

How to use

- Run npm install.
- Add your firebase config details to Server/firebase.js.
- Run "npm run start" to start the app.


Project Link

Project Console: https://console.firebase.google.com/project/meet-clone-9d29e/overview
Hosting URL: https://meet-clone-9d29e.web.app
